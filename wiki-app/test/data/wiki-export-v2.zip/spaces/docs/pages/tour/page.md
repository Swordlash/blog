# Tour

This is the demo of a wiki written in Haskell: spaces of Markdown pages,
an editor with the page rendered beside it as you type, search, and
permissions on spaces. It runs entirely in your browser, over a wiki kept
in your browser too, and nothing you do here is sent anywhere.

> [!NOTE]
> Your edits are kept in this browser, so a reload finds them. On the
> **Administration** page, linked at the top right for an administrator,
> **Export the wiki** saves all of it as a zip file, **Import a wiki** brings
> such a file back, and **Reset the demo content** puts back the pages you
> see now.

## Who you can be

You start as `admin`, Ada Admin, who may do everything. There are no
passwords in the demo: choose who you are with the menu at the top right,
and the same wiki shows what that person may read and do:

| Who                      | May                                                  |
| ------------------------ | ---------------------------------------------------- |
| nobody (not signed in)   | read the public spaces, **Blog** and **Docs**        |
| `reader`, Rita Reader    | also read **Team / Projects**, but nothing else of Team |
| `editor`, Edgar Editor   | also write in **Blog**, and create spaces            |
| `admin`, Ada Admin       | everything, everywhere                               |

## Public and private spaces

A space holds pages, and other spaces. The front page lists the spaces
you may read, and those you visited last; inside a space, the sidebar
shows that space alone: its pages, its subspaces, and a menu to switch
to another. [Blog](/blog) and [Docs](/docs), where this page is, are
public: anyone may read them, signed in or not. **Team** is private, and
so is its subspace **Team / Projects**, which `reader` has been let into:
`reader` sees Team only as the way there. Look at the front page as
`admin`, then as nobody, then as `reader`. (A link to a space you may
not see shows as broken, since for you there is nothing there.)

A space opens at its home page, which is this one for Docs. **Pages and
settings**, in the sidebar, lists all of a space's pages, and there
whoever administers the space gives it a description, an icon (an
emoji, a colour, or an image) and another home page.

## What a page can be

The [Markdown guide](markdown-guide) shows everything a page can have:
headings, lists, tables, task lists, footnotes, code highlighted by its
language, formulas drawn by KaTeX, diagrams drawn by Mermaid, pictures
drawn with TikZ, images, a video and an attached file. Its subpages are about
[diagrams](markdown-guide/diagrams) and [mathematics](markdown-guide/mathematics).
Open any of them in the editor to see the Markdown it is written in.

## Writing

1. As `admin`, open any page, this one too, or be `editor` and open a
   post in the Blog, such as [Hello, world](/blog/hello-world). Choose
   **Edit**.
2. Type on the left: the preview on the right follows when you stop.
3. Drag an image, or any other file, onto the editor to attach it to the
   page: the Markdown that shows it goes in where the cursor is.
4. Save with **Save**, or Ctrl+S (Cmd+S on a Mac). Leaving with changes
   that are not saved asks first.

A space's **New page**, and a page's **New subpage**, start a page from
nothing.

## Being told

Write `@` and a login to mention someone: @editor is told of it under the
bell at the top, beside the name of whoever is signed in. So are comments
on the pages someone watches (their own, and those of the spaces they
chose to with a page's or a space's **Watch** button), and their changes.
Mention @editor in a comment as `admin`, then switch to `editor`.

## Finding

Press `/` anywhere outside a text field, or click the search box at the
top, and type: the best pages show as you type, with your words marked.
The selector beside the box keeps the search to one space and its
subspaces. The arrow keys choose a page and Enter opens it; Enter with
none chosen opens the page of every result. Search finds only what you
may read: search for *on-call* as `admin`, then as nobody.

## Not there yet

This is the first demo. Still to come:

- a server that keeps the pages for everyone, not in one browser only;
- signing in with a password, instead of choosing who you are;
- the permissions enforced by that server, and pages to administer them;
- the history of every page, with what changed between its versions.
