# Markdown guide

Everything a page can have, in the Markdown it is written in. Open this
page in the editor to see the source.

## Text

Paragraphs, *emphasis*, **strong emphasis**, ~~strikethrough~~,
`inline code` and links, to the web (<https://commonmark.org>) or to other
pages by their path from this one: [diagrams](markdown-guide/diagrams), or
the [tour](tour) next to this page, or [[tour|the same, as a wiki link]].[^paths]

### Lists

- Bullets
  - nested
- and numbers:

1. one
2. two

### Tasks

- [x] Write the page
- [ ] Read it

### Tables

| Feature  | Syntax              | Shown as         |
| -------- | ------------------- | ---------------: |
| Math     | `$…$`, `$$…$$`      | KaTeX            |
| Diagrams | a `mermaid` fence   | Mermaid          |
| Pictures | a `tikz` fence      | TikZ, by TikZJax |
| Code     | a fence with a name | highlight.js     |

> A quotation, for good measure.

## Code

```haskell
main :: IO ()
main = putStrLn "Hello, world"
```

```javascript
const answer = [6, 7].reduce((a, b) => a * b);
```

## Mathematics

Inline, $a^2 + b^2 = c^2$, and on a line of its own:

$$\int_{-\infty}^{\infty} e^{-x^2} \, dx = \sqrt{\pi}$$

Chemistry with `\ce`: $\ce{2 H2 + O2 -> 2 H2O}$. Macros, built in, of the
space or of the page, are on [Mathematics](markdown-guide/mathematics).

## Diagrams

```mermaid
flowchart TD
  Markdown --> Parser[commonmark]
  Parser --> Halogen[Halogen HTML]
  Halogen --> Page
```

## Pictures

A `tikz` fence is drawn by TikZ, where you say where everything goes:

```tikz
\draw[->] (-0.5,0) -- (3.5,0) node[right] {$x$};
\draw[->] (0,-0.5) -- (0,2.5) node[above] {$y$};
\draw[thick, blue] (0,0.5) .. controls (1,2.5) and (2,-0.5) .. (3,1.5);
\fill (1.5,1) circle (2pt) node[above right] {a point};
```

## Images, video and attachments

An image from the web:

![The Earth seen from Apollo 17 (NASA, public domain)](https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/The_Earth_seen_from_Apollo_17.jpg/960px-The_Earth_seen_from_Apollo_17.jpg)

A video from the web, written as an image whose address is a video:

![Sarychev Peak erupting, seen from the International Space Station (NASA, public domain)](https://upload.wikimedia.org/wikipedia/commons/transcoded/8/82/Sarychev_Peak_eruption_on_12_June_2009%2C_oblique_satellite_view.ogv/Sarychev_Peak_eruption_on_12_June_2009%2C_oblique_satellite_view.ogv.480p.vp9.webm)

And a file attached to this page, by its name:

![A tree](attachment:tree.png)

[^paths]: A path without a leading slash is read from this page's own
    address, as a browser reads a relative link.
