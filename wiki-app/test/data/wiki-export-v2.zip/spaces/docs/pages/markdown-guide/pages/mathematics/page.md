# Mathematics

Between single dollars inline, $e^{i\pi} + 1 = 0$, and between double
dollars on a line of their own:

$$
\begin{pmatrix} a & b \\ c & d \end{pmatrix}^{-1}
= \frac{1}{ad - bc} \begin{pmatrix} d & -b \\ -c & a \end{pmatrix}
$$

A `math` fence is display math too:

```math
\sum_{n=1}^{\infty} \frac{1}{n^2} = \frac{\pi^2}{6}
```

## Macros

KaTeX has no `\usepackage`, so the wiki has macros instead, in three
layers, the nearest winning. Some are built in, for every page:
$\abs{x}$, $\norm{v}$, $\floor{x} \le x \le \ceil{x}$,
$\Q \subset \R \subset \C$, $\E[X]$ and $\Var(X)$.

This space has its own, in its settings, which its pages and its
subspaces' pages may use: $\vect{v} \in V$, $f \in \Hom(V, W)$; and
here $\eps$ is $\epsilon$, where the built-in one is $\varepsilon$.

And a formula may define its own, which hold in every formula after it on
the page, as in a LaTeX document:

$$
\newcommand{\dist}[2]{d\left(#1, #2\right)}
\dist{x}{z} \le \dist{x}{y} + \dist{y}{z}
$$

so that from here on $\dist{x}{x} = 0$.

## Chemistry

`\ce` writes chemical formulas and equations (mhchem): $\ce{H2O}$,
$\ce{SO4^2-}$, and

$$\ce{CO2 + C -> 2 CO}$$

$$\ce{Hg^2+ ->[I-] HgI2 ->[I-] [Hg^{II}I4]^2-}$$

and `\pu` quantities with their units: $\pu{123 kJ/mol}$.
