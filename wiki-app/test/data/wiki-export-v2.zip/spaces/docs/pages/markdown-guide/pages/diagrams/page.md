# Diagrams

A `mermaid` fence is drawn by Mermaid, in the browser.

```mermaid
classDiagram
  Space "1" --> "*" Page
  Space "1" --> "*" Space : subspaces
  Page "1" --> "*" Attachment
```

```mermaid
pie title Where the time goes
  "Writing" : 60
  "Rewriting" : 30
  "Naming things" : 10
```

A `tikz` fence is drawn by TikZ, which TeX runs in your browser. It holds
the commands of a picture, or a whole `tikzpicture`, or a commutative
diagram:

```tikz
\begin{tikzcd}
  A \arrow[r, "f"] \arrow[d, "h"'] & B \arrow[d, "g"] \\
  C \arrow[r, "k"'] & D
\end{tikzcd}
```

A line at the top of the fence that loads a library, or a package, is read
before the picture, as LaTeX wants it:

```tikz
\usetikzlibrary{positioning, arrows.meta}
\begin{tikzpicture}[node distance=2cm, box/.style={draw, rounded corners}, >={Stealth[length=3mm]}]
  \node[box] (md) {Markdown};
  \node[box, right=of md] (html) {Halogen HTML};
  \node[box, right=of html] (page) {the page};
  \draw[->] (md) -- node[above] {parse} (html);
  \draw[->] (html) -- node[above] {render} (page);
\end{tikzpicture}
```

A plot, with pgfplots:

```tikz
\begin{tikzpicture}
\begin{axis}[xlabel=$x$, ylabel={$\sin x$}, width=8cm, height=5cm]
  \addplot[domain=0:360, samples=60, thick] {sin(x)};
\end{axis}
\end{tikzpicture}
```
