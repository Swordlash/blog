# Presentations

::: {.slides theme=beamer aspect=16:9}
:::

Any page can be a slide deck. Press **Present** above the page: this one is
a deck, and its slides tell you how it is written.

::: notes
These are the speaker's notes: on the page they are a box like this one;
on the slides they are hidden until you press **n**.
:::

---

## Slides

- A line with `---` alone on it, after a blank line, starts the next slide.
- The first heading on a slide is its title; a `#` heading makes a title
  slide, like this deck's first.
- A `::: notes` box holds what only the speaker sees.
- Everything a page shows, a slide shows: tables, code, formulas, diagrams.

::: notes
Mention that a page with no `---` is one slide, and is not offered as a
deck.
:::

---

## Formulas

Euler's identity, $e^{i\pi} + 1 = 0$, set by KaTeX, and on its own:

$$
\int_{-\infty}^{\infty} e^{-x^2}\,dx = \sqrt{\pi}
$$

::: notes
The macros a page defines hold on every slide after the one that defines them.
:::

---

## A diagram

```mermaid
flowchart LR
  page[A page] -->|---| slides[Slides]
  slides --> screen[Full screen]
  slides --> paper[Print to PDF]
```

---

## Code

```haskell
-- A deck is a page's Markdown, cut at its breaks.
deckOf :: [Block] -> Deck
```

---

## Presenting

| Key | What it does |
| --- | --- |
| → Space PageDown | the next slide |
| ← PageUp | the slide before |
| Home End | the first and the last |
| f | full screen (Escape leaves it) |
| n | the speaker's notes |
| o | every slide, to pick one |

On a touch screen, swipe. **Print** puts one slide on each page: choose
"Save as PDF" to keep the deck as a file.

---

## Themes

A `slides` box anywhere in the page says how the slides look:

```markdown
::: {.slides theme=dark aspect=4:3}
:::
```

Themes are `beamer` (the default), `light` and `dark`; slides are `16:9`
(the default) or `4:3`.
