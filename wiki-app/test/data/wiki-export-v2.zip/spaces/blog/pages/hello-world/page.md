# Hello, world

This is the first post of a blog that is also a wiki. Every page is
Markdown, written in a split view with the page rendered next to it as
you type.

## Why a wiki

- Pages live in **spaces**, and spaces in other spaces.
- A space can be *public*, which is what makes this a blog.
- Everything else is up to who may view, edit or administer what.

![The Earth seen from Apollo 17 (NASA, public domain)](https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/The_Earth_seen_from_Apollo_17.jpg/960px-The_Earth_seen_from_Apollo_17.jpg)

The next post is about [the language this is written in](notes-on-haskell).
