# Notes on Haskell

The wiki is written in Haskell and compiled to WebAssembly; the page you
are reading was rendered by `Wiki.Core` in your browser.[^wasm]

```haskell
-- The slug a title suggests: lowercase ASCII, single dashes.
slugify :: Text -> Maybe Slug

fibonacci :: [Integer]
fibonacci = 0 : 1 : zipWith (+) fibonacci (drop 1 fibonacci)
```

Laziness is what lets `fibonacci` be infinite: the $n$-th element is
computed once something asks for it, and it grows like $\varphi^n$, where

$$\varphi = \frac{1 + \sqrt{5}}{2}$$

[^wasm]: With GHC's WebAssembly backend, through haskell-halogen.
