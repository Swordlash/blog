# Team handbook

Private to the team: only people granted a permission on this space, or
on the wiki as a whole, can read it.

[[toc]]

## The week

| Day       | Who   | What                 |
| --------- | ----- | -------------------- |
| Monday    | Ada   | Planning             |
| Wednesday | Edgar | Reviews              |
| Friday    | Rita  | Demo of the week     |

## Before your first day

- [x] Get an account
- [x] Read this page
- [ ] Read [on-call](team-handbook/on-call)

## Meetings

Notes of a meeting start from the team's [Weekly sync](weekly-sync)
template: choose it under "New page".
