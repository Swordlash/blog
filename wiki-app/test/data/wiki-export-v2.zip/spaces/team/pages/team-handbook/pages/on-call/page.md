# On-call

What happens when something breaks at night:

```mermaid
sequenceDiagram
  participant Monitor
  participant OnCall as On-call
  participant Team
  Monitor->>OnCall: page
  OnCall->>OnCall: look, fix if it is quick
  OnCall-->>Team: write it up in the morning
```
