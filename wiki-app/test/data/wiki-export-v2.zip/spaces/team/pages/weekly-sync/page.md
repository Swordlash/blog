# {{title}}

Weekly sync of {{date}}, notes by {{author}}.

## Since last week

- 

## Blocked

- 

## Next

- [ ] 
