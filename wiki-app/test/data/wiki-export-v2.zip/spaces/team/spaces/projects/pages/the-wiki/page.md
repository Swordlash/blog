# The wiki

The project that made this page. `reader` can see it, though not the rest
of the team's space: a grant on a subspace is a grant there only.

![The tree of spaces and pages](attachment:tree.png)

## Milestones

- [x] A serverless demo, in the browser
- [ ] A server that keeps the pages
- [ ] Sign-in and permissions enforced on the server

```mermaid
flowchart LR
  Demo[Serverless demo] --> Server[Server with SQLite]
  Server --> Auth[Accounts and permissions]
```
